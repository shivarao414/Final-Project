package com.shivarao.major.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shivarao.major.model.Role;
import com.shivarao.major.model.User;

public interface RoleRepository extends JpaRepository<Role, Integer> {
	
//	Optional<Role>findRoleById(int id);

}
